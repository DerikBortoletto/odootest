Changelog
=========


Version 1.0 Release Candidate 1 (2014-06-27)
--------------------------------------------

Initial release.
